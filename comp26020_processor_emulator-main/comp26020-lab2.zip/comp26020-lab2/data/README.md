# Program descriptions

- state1.txt: Calculates 3 * 4, stores it position 35, and then remains stuck at instruction in position 32
- state2.txt: Calculates the sum of all numbers in positions 64-95 and stores the result in position 63
- state3.txt: No real program. Memory is filled with successive numbers from 0 to 255
- state4.txt: No real program. Memory is filled with successive instruction opcodes.
