var searchData=
[
  ['memory_0',['memory',['../structProcessorState.html#a850eddf28f8fd32e8cd6478b6c41e75e',1,'ProcessorState']]]
];
