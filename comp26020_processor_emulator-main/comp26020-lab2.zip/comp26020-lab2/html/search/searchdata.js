var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprst",
  1: "beip",
  2: "_bcdefghilnoprst",
  3: "amp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

