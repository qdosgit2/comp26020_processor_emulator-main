var searchData=
[
  ['load_5fstate_0',['load_state',['../classEmulator.html#af8620ad10114e37017232b80c87463b8',1,'Emulator']]]
];
