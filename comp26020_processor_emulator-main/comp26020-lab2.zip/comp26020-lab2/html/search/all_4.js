var searchData=
[
  ['decode_0',['decode',['../classEmulator.html#a741c865a59e67068e495910f40a8e49b',1,'Emulator']]],
  ['delete_5fbreakpoint_1',['delete_breakpoint',['../classEmulator.html#a0ada161d8e15bc9e74041f51d96ae416',1,'Emulator::delete_breakpoint(addr_t address)'],['../classEmulator.html#a7632f6f238459d3a131d7671998033da',1,'Emulator::delete_breakpoint(const char *name)']]]
];
