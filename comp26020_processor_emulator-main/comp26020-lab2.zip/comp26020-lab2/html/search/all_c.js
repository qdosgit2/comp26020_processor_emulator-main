var searchData=
[
  ['name_0',['name',['../classInstructionBase.html#a6e11e7e1d183f271e8503b7a87b93c11',1,'InstructionBase::name()'],['../classIadd.html#a4df8e11a2df426cd9431d5e9b5783b64',1,'Iadd::name()'],['../classIand.html#a2a70624447c9261d3c558a00303fda6a',1,'Iand::name()'],['../classIorr.html#a625568ed333a0ebba62591c7ff202809',1,'Iorr::name()'],['../classIxor.html#a96330a00397ad4709cd78d14af4fc41d',1,'Ixor::name()'],['../classIldr.html#a992e6919008619514de26abf22d3e04f',1,'Ildr::name()'],['../classIstr.html#a0a1d8eaea083ae552dec80057a668d57',1,'Istr::name()'],['../classIjmp.html#a02a72e41be117ca1e71800db8261f814',1,'Ijmp::name()'],['../classIjne.html#a40bff9402aa9f2d867cf18e91cb2a931',1,'Ijne::name()']]],
  ['num_5fbreakpoints_1',['num_breakpoints',['../classEmulator.html#ae66273ad3490914f38bf75681ca04046',1,'Emulator']]]
];
