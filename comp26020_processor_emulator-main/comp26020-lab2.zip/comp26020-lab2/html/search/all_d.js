var searchData=
[
  ['operator_3d_0',['operator=',['../classEmulator.html#a595bee846464f5e06f2c196e414b8283',1,'Emulator::operator=(const Emulator &amp;other)'],['../classEmulator.html#a7b027ce029681851481ecb1e7c811508',1,'Emulator::operator=(Emulator &amp;&amp;other) noexcept']]]
];
