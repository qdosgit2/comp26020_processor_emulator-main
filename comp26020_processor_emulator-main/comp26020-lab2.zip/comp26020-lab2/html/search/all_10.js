var searchData=
[
  ['save_5fstate_0',['save_state',['../classEmulator.html#ae1bc9d1fe915452a05a6c147cf06ca8d',1,'Emulator']]]
];
